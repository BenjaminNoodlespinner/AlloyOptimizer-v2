package optimizer;

public class VesselOptimizer {
	
}
