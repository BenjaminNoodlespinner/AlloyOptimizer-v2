package com.jam.alloyoptimizer;

public class OptimizationFailDialog extends WrongInputDialog{

}
