package com.jam.alloyoptimizer;

public interface DialogClickListener {
	public void onOkClick(String string, int index, boolean ingot);
	public void onClearCLick(String string, int index, boolean ingot);
}
